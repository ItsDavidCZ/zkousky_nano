import React from 'react';
import { Zap, Target, BookOpen, PlayCircle, Brain } from 'lucide-react';
import { User, ViewState, ExamConfig } from '../types';

interface HomeProps {
    user: User;
    setView: (v: ViewState) => void;
    startQuickExam: (cfg: ExamConfig) => void;
}

export const Home: React.FC<HomeProps> = ({ user, setView, startQuickExam }) => {
    return (
        <div className="p-6 space-y-8 pb-28 pt-10">
            <header className="flex justify-between items-start">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Ahoj, {user.displayName.split(' ')[0]}! 👋</h1>
                    <p className="text-gray-600 dark:text-gray-400 mt-1 font-medium">Připraven na dnešní trénink?</p>
                </div>
                <div className="flex flex-col items-end">
                    <div className="flex items-center space-x-1 bg-orange-100 dark:bg-orange-900/40 text-orange-700 dark:text-orange-400 px-3 py-1 rounded-full text-sm font-bold border border-orange-200 dark:border-orange-800">
                        <Zap size={14} fill="currentColor" />
                        <span>{user.pocetDniStreak} dní</span>
                    </div>
                </div>
            </header>

            {/* Main Stats */}
            <div className="grid grid-cols-2 gap-4">
                <div className="bg-white dark:bg-gray-800 p-5 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700">
                    <div className="text-gray-500 dark:text-gray-400 text-xs font-bold uppercase tracking-wider mb-2">Celkové Skóre</div>
                    <div className="text-3xl font-bold text-indigo-600 dark:text-indigo-400">{user.celkoveSkore.toLocaleString()}</div>
                </div>
                <div className="bg-white dark:bg-gray-800 p-5 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700">
                    <div className="text-gray-500 dark:text-gray-400 text-xs font-bold uppercase tracking-wider mb-2">Dnešní Cíl</div>
                    <div className="text-3xl font-bold text-green-500 dark:text-green-400">80%</div>
                </div>
            </div>

            {/* Quick Actions */}
            <div className="space-y-4">
                <h2 className="text-lg font-bold text-gray-800 dark:text-white">Rychlý start</h2>
                
                <div onClick={() => setView('exam_select')} className="group relative overflow-hidden bg-gradient-to-br from-indigo-500 to-purple-600 rounded-3xl p-6 text-white shadow-lg shadow-indigo-200 dark:shadow-none cursor-pointer active:scale-[0.98] transition-transform">
                    <div className="relative z-10">
                        <div className="bg-white/20 w-10 h-10 rounded-full flex items-center justify-center mb-3 backdrop-blur-sm border border-white/10">
                             <PlayCircle size={24} />
                        </div>
                        <h3 className="text-xl font-bold">Simulace Zkoušky</h3>
                        <p className="text-indigo-100 text-sm mt-1 opacity-90 font-medium">Kompletní test z matematiky nebo češtiny.</p>
                    </div>
                    <div className="absolute -right-5 -bottom-5 w-32 h-32 bg-white/10 rounded-full blur-2xl group-hover:bg-white/20 transition-colors"></div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                     <button onClick={() => startQuickExam({ mode: 'panic' })} className="bg-white dark:bg-gray-800 p-4 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 text-left active:scale-95 transition-transform hover:border-red-200 dark:hover:border-red-900">
                        <Target className="text-red-500 dark:text-red-400 mb-2" />
                        <div className="font-bold text-gray-800 dark:text-gray-100">Panic Mode</div>
                        <div className="text-xs text-gray-500 dark:text-gray-400 font-medium">Kritické otázky</div>
                     </button>

                     <button onClick={() => startQuickExam({ mode: 'review' })} className="bg-white dark:bg-gray-800 p-4 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 text-left active:scale-95 transition-transform hover:border-blue-200 dark:hover:border-blue-900">
                        <BookOpen className="text-blue-500 dark:text-blue-400 mb-2" />
                        <div className="font-bold text-gray-800 dark:text-gray-100">Opravit chyby</div>
                        <div className="text-xs text-gray-500 dark:text-gray-400 font-medium">Moje slabiny</div>
                     </button>
                </div>
            </div>
            
            {/* AI Teaser */}
            <div onClick={() => setView('ai_tutor')} className="bg-gray-900 dark:bg-indigo-900/30 dark:border dark:border-indigo-500/30 text-white rounded-2xl p-5 flex items-center justify-between cursor-pointer shadow-lg shadow-gray-200 dark:shadow-none">
                <div>
                    <h3 className="font-bold text-white">AI Doučování</h3>
                    <p className="text-gray-400 dark:text-indigo-200 text-xs">Zeptej se na cokoliv k učivu</p>
                </div>
                <Brain className="text-purple-400 dark:text-indigo-300" />
            </div>
        </div>
    );
};