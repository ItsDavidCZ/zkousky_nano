import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ArrowLeft, Clock, AlertTriangle, Brain, CheckCircle, XCircle, Loader2 } from 'lucide-react';
import { db } from '../services/mockDb';
import { geminiService } from '../services/geminiService';
import { Question, ExamConfig } from '../types';

interface ExamProps {
  onBack: () => void;
  config?: ExamConfig; // If passed, skips selection
}

export const Exam: React.FC<ExamProps> = ({ onBack, config: initialConfig }) => {
  // State
  const [mode, setMode] = useState<'select' | 'active' | 'result'>('select');
  const [examConfig, setExamConfig] = useState<ExamConfig>(initialConfig || { mode: 'simulation' });
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [timeLeft, setTimeLeft] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({}); // qId -> answer
  const [score, setScore] = useState(0);
  
  // AI Logic
  const [showErrorPopup, setShowErrorPopup] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiExplanation, setAiExplanation] = useState<string | null>(null);
  const [currentWrongQ, setCurrentWrongQ] = useState<Question | null>(null);

  // Result Screen Explanations
  const [resultExplanations, setResultExplanations] = useState<Record<string, string>>({});
  const [loadingExplanationId, setLoadingExplanationId] = useState<string | null>(null);

  // Load questions based on config
  useEffect(() => {
    if (initialConfig) {
      startExam(initialConfig);
    }
  }, [initialConfig]);

  const startExam = (cfg: ExamConfig) => {
    let allQ = db.getQuestions();
    let filteredQ: Question[] = [];

    if (cfg.mode === 'panic') {
      filteredQ = allQ.filter(q => q.isCritical).slice(0, 10);
    } else if (cfg.mode === 'review') {
      const errors = db.getErrors();
      const errorQIds = new Set(errors.filter(e => !e.isCorrected).map(e => e.questionId));
      filteredQ = allQ.filter(q => errorQIds.has(q.id)).slice(0, 10);
    } else if (cfg.mode === 'simulation') {
      if (cfg.subject) {
        filteredQ = allQ.filter(q => q.predmet === cfg.subject);
      } else {
        filteredQ = allQ; // Fallback
      }
    }

    // Shuffle logic could go here
    setQuestions(filteredQ);
    setExamConfig(cfg);
    setTimeLeft(cfg.duration || (cfg.subject === 'Matematika' ? 75 * 60 : 60 * 60));
    setMode('active');
    setCurrentQIndex(0);
    setAnswers({});
    setScore(0);
    setResultExplanations({});
  };

  // Timer
  useEffect(() => {
    let interval: number;
    if (mode === 'active' && timeLeft > 0) {
      interval = window.setInterval(() => {
        setTimeLeft(prev => {
            if (prev <= 1) {
                finishExam();
                return 0;
            }
            return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [mode, timeLeft]);

  const handleExit = () => {
    if (window.confirm("Opravdu chcete odejít? Postup bude ztracen.")) {
      onBack();
    }
  };

  const handleAnswer = (answer: string) => {
    const currentQ = questions[currentQIndex];
    const isCorrect = answer === currentQ.spravnaOdpoved;
    
    setAnswers(prev => ({ ...prev, [currentQ.id]: answer }));

    if (isCorrect) {
      if (examConfig.mode === 'review') {
        db.markErrorCorrected(currentQ.id);
      }
      proceedToNext(true);
    } else {
      // Log error
      db.logError(currentQ.id);
      setCurrentWrongQ(currentQ);
      setShowErrorPopup(true); // Interrupt flow for AI
    }
  };

  const proceedToNext = (wasCorrect: boolean) => {
    if (wasCorrect) setScore(s => s + 1);

    if (currentQIndex < questions.length - 1) {
      setCurrentQIndex(prev => prev + 1);
    } else {
      finishExam();
    }
  };

  const finishExam = () => {
    setMode('result');
    // Update User Total Score
    const earnedScore = questions.reduce((acc, q) => {
       return acc + (answers[q.id] === q.spravnaOdpoved ? 10 : 0);
    }, 0);
    
    if (earnedScore > 0) {
        db.updateUser({ celkoveSkore: db.getCurrentUser().celkoveSkore + earnedScore });
    }
  };

  const handleAIExplain = async () => {
    if (!currentWrongQ) return;
    setAiLoading(true);
    const explanation = await geminiService.getExplanation(currentWrongQ, answers[currentWrongQ.id] || '?');
    setAiExplanation(explanation);
    setAiLoading(false);
  };

  const handleResultExplain = async (q: Question) => {
    setLoadingExplanationId(q.id);
    const answer = answers[q.id] || "Neodpovězeno";
    const explanation = await geminiService.getExplanation(q, answer);
    setResultExplanations(prev => ({...prev, [q.id]: explanation}));
    setLoadingExplanationId(null);
  };

  const closePopupAndNext = () => {
    setShowErrorPopup(false);
    setAiExplanation(null);
    proceedToNext(false);
  };

  const createFlashcards = () => {
    const cards = questions.map(q => ({
      category: 'Můj poslední test',
      front: q.otazka,
      back: `Správně: ${q.spravnaOdpoved}. ${q.vysvetleniChyby}`
    }));
    db.addFlashcards(cards);
    alert('Kartičky vytvořeny!');
  };

  // --- RENDER: SELECTION ---
  if (mode === 'select') {
    return (
      <div className="p-6 space-y-6 pt-12 pb-24">
        <h1 className="text-2xl font-bold text-gray-800 dark:text-white">Režim Zkoušky</h1>
        
        <div className="space-y-4">
          <button onClick={() => startExam({ mode: 'simulation', subject: 'Matematika', duration: 75 * 60 })} 
            className="w-full p-6 bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 flex items-center space-x-4 active:scale-95 transition-transform">
            <div className="bg-blue-100 dark:bg-blue-900/30 p-3 rounded-full text-blue-600 dark:text-blue-400"><Clock /></div>
            <div className="text-left">
              <h3 className="font-bold text-lg text-gray-900 dark:text-white">Matematika</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">75 minut • Simulace přijímaček</p>
            </div>
          </button>

          <button onClick={() => startExam({ mode: 'simulation', subject: 'Čeština', duration: 60 * 60 })} 
            className="w-full p-6 bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 flex items-center space-x-4 active:scale-95 transition-transform">
            <div className="bg-red-100 dark:bg-red-900/30 p-3 rounded-full text-red-600 dark:text-red-400"><Clock /></div>
            <div className="text-left">
              <h3 className="font-bold text-lg text-gray-900 dark:text-white">Český Jazyk</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">60 minut • Simulace přijímaček</p>
            </div>
          </button>

           <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
             <p className="text-gray-500 dark:text-gray-400 mb-2 font-semibold">Adaptivní Trénink</p>
             <button onClick={() => startExam({ mode: 'panic' })} 
                className="w-full mb-3 p-4 bg-orange-50 dark:bg-orange-900/20 rounded-xl border border-orange-100 dark:border-orange-800 text-orange-700 dark:text-orange-400 font-semibold flex items-center justify-center space-x-2">
                <AlertTriangle size={18} /> <span>Panic Mode (Kritické otázky)</span>
             </button>
             <button onClick={() => startExam({ mode: 'review' })} 
                className="w-full p-4 bg-purple-50 dark:bg-purple-900/20 rounded-xl border border-purple-100 dark:border-purple-800 text-purple-700 dark:text-purple-300 font-semibold flex items-center justify-center space-x-2">
                <Brain size={18} /> <span>Opravit mé chyby</span>
             </button>
           </div>
        </div>
      </div>
    );
  }

  // --- RENDER: RESULT ---
  if (mode === 'result') {
    const correctCount = questions.filter(q => answers[q.id] === q.spravnaOdpoved).length;
    const percentage = Math.round((correctCount / questions.length) * 100) || 0;
    const wrongAnswers = questions.filter(q => answers[q.id] !== q.spravnaOdpoved);

    return (
      <div className="min-h-screen bg-white dark:bg-gray-900 pb-24">
        <div className="p-6 flex flex-col items-center pt-12">
            {/* Score Summary */}
            <div className="text-6xl mb-4">{percentage >= 50 ? '🎉' : '📚'}</div>
            <h2 className="text-3xl font-bold mb-2 text-gray-900 dark:text-white">{percentage}% Úspěšnost</h2>
            <p className="text-gray-500 dark:text-gray-400 mb-8">Získal jsi {correctCount} z {questions.length} bodů</p>
            
            {/* Actions */}
            <div className="w-full space-y-3 mb-8">
            <button onClick={createFlashcards} className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold shadow-lg shadow-indigo-200 dark:shadow-none transition-colors">
                Vytvořit Kartičky z tohoto testu
            </button>
            <button onClick={onBack} className="w-full py-3 text-gray-600 dark:text-gray-300 font-medium border border-gray-200 dark:border-gray-700 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                Zpět na Domovskou obrazovku
            </button>
            </div>

            {/* Review Section */}
            {wrongAnswers.length > 0 && (
                <div className="w-full">
                    <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4 flex items-center gap-2">
                        <AlertTriangle className="text-orange-500" size={20} />
                        Chyby k prozkoumání
                    </h3>
                    <div className="space-y-4">
                        {wrongAnswers.map(q => {
                            const userAnswer = answers[q.id];
                            const userText = userAnswer ? (q as any)[`odpoved${userAnswer}`] : "Neodpovězeno";
                            const correctText = (q as any)[`odpoved${q.spravnaOdpoved}`];
                            
                            return (
                                <div key={q.id} className="bg-gray-50 dark:bg-gray-800 p-4 rounded-2xl border border-gray-100 dark:border-gray-700">
                                    <p className="font-medium text-gray-800 dark:text-gray-200 mb-3">{q.otazka}</p>
                                    
                                    <div className="grid gap-2 mb-3">
                                        <div className="flex items-center gap-2 text-sm text-red-700 dark:text-red-300 bg-red-100 dark:bg-red-900/30 p-2 rounded-lg">
                                            <XCircle size={16} /> <span className="font-semibold">Tvoje odpověď:</span> {userText}
                                        </div>
                                        <div className="flex items-center gap-2 text-sm text-green-700 dark:text-green-300 bg-green-100 dark:bg-green-900/30 p-2 rounded-lg">
                                            <CheckCircle size={16} /> <span className="font-semibold">Správně:</span> {correctText}
                                        </div>
                                    </div>
                                    
                                    {resultExplanations[q.id] ? (
                                        <div className="bg-white dark:bg-gray-900 p-4 rounded-xl border border-indigo-100 dark:border-indigo-900/50 shadow-sm mt-3 animate-in fade-in slide-in-from-top-2">
                                            <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400 font-bold mb-2 text-sm">
                                                <Brain size={16} /> AI Vysvětlení
                                            </div>
                                            <p className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed">{resultExplanations[q.id]}</p>
                                        </div>
                                    ) : (
                                        <button 
                                            onClick={() => handleResultExplain(q)}
                                            disabled={loadingExplanationId === q.id}
                                            className="w-full py-2 mt-2 bg-white dark:bg-gray-700 border border-indigo-200 dark:border-gray-600 text-indigo-600 dark:text-indigo-300 rounded-lg text-sm font-bold flex items-center justify-center gap-2 hover:bg-indigo-50 dark:hover:bg-gray-600 transition-colors"
                                        >
                                            {loadingExplanationId === q.id ? <Loader2 className="animate-spin" size={16}/> : <Brain size={16}/>}
                                            {loadingExplanationId === q.id ? 'Generuji...' : 'Proč je to špatně? (AI)'}
                                        </button>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}
        </div>
      </div>
    );
  }

  // --- RENDER: ACTIVE EXAM ---
  const currentQ = questions[currentQIndex];
  if (!currentQ) return <div className="p-10 text-center text-gray-500 dark:text-gray-400">Načítání... nebo žádné otázky k dispozici.</div>;

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900 pb-safe">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 p-4 shadow-sm sticky top-0 z-10 flex justify-between items-center border-b border-gray-100 dark:border-gray-700 transition-colors">
         <button onClick={handleExit} className="text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-white"><ArrowLeft /></button>
         <div className="font-mono text-lg font-bold text-primary dark:text-indigo-400">
            {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}
         </div>
         <div className="text-sm text-gray-400 dark:text-gray-500">{currentQIndex + 1} / {questions.length}</div>
      </div>

      {/* Question */}
      <div className="flex-1 p-6 overflow-y-auto pb-32">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 mb-6 transition-colors">
            <span className="text-xs font-bold tracking-wider text-gray-400 dark:text-gray-500 uppercase mb-2 block">{currentQ.predmet} • {currentQ.tema}</span>
            <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100 leading-relaxed">{currentQ.otazka}</h2>
        </div>

        <div className="space-y-3">
            {['A', 'B', 'C'].map((option) => (
                <button
                    key={option}
                    onClick={() => handleAnswer(option)}
                    className="w-full p-4 text-left bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 hover:border-indigo-500 dark:hover:border-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 transition-all active:scale-[0.98] group"
                >
                    <span className="font-bold text-indigo-600 dark:text-indigo-400 mr-2 group-hover:text-indigo-700 dark:group-hover:text-indigo-300">{option})</span>
                    <span className="text-gray-700 dark:text-gray-300 group-hover:text-gray-900 dark:group-hover:text-white">
                        {(currentQ as any)[`odpoved${option}`]}
                    </span>
                </button>
            ))}
        </div>
      </div>

      {/* AI Explanation Popup */}
      {showErrorPopup && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm p-4">
            <div className="bg-white dark:bg-gray-800 w-full max-w-md rounded-3xl p-6 shadow-2xl animate-in slide-in-from-bottom duration-300 border border-gray-100 dark:border-gray-700">
                <div className="flex items-center space-x-3 mb-4 text-red-500 dark:text-red-400">
                    <XCircle size={32} />
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white">Chyba!</h3>
                </div>
                
                {!aiExplanation ? (
                    <p className="text-gray-600 dark:text-gray-300 mb-6">Chceš vysvětlit, proč je tvá odpověď špatná?</p>
                ) : (
                    <div className="bg-indigo-50 dark:bg-indigo-900/30 p-4 rounded-xl mb-6 text-sm text-indigo-900 dark:text-indigo-200 leading-relaxed border border-indigo-100 dark:border-indigo-800">
                       <div className="font-bold mb-1 flex items-center gap-2"><Brain size={14}/> AI Lektor:</div>
                       {aiExplanation}
                    </div>
                )}

                <div className="flex space-x-3">
                    {!aiExplanation ? (
                        <>
                            <button 
                                onClick={handleAIExplain} disabled={aiLoading}
                                className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold flex justify-center items-center transition-colors">
                                {aiLoading ? <Loader2 className="animate-spin" /> : 'ANO, vysvětlit'}
                            </button>
                            <button onClick={closePopupAndNext} className="flex-1 py-3 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200 rounded-xl font-semibold hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors">
                                NE, pokračovat
                            </button>
                        </>
                    ) : (
                        <button onClick={closePopupAndNext} className="w-full py-3 bg-gray-900 dark:bg-gray-700 text-white rounded-xl font-semibold hover:bg-gray-800 dark:hover:bg-gray-600 transition-colors">
                            Chápu, jdeme dál
                        </button>
                    )}
                </div>
            </div>
        </div>
      )}
    </div>
  );
};