import React, { useState, useEffect } from 'react';
import { db } from './services/mockDb';
import { User, ViewState, ExamConfig } from './types';
import BottomNav from './components/BottomNav';
import { Home } from './pages/Home';
import { Exam } from './pages/Exam';
import { geminiService } from './services/geminiService';
import { ArrowRight, MessageSquare, Save, Moon, Sun, ChevronRight } from 'lucide-react';

// Simplified components for other views to fit file constraints
const Leaderboard = () => {
    const users = [db.getCurrentUser(), { displayName: 'Anna K.', celkoveSkore: 12500 }, { displayName: 'Tomáš M.', celkoveSkore: 9800 }];
    return (
        <div className="p-6 pt-10 pb-24">
            <h1 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white">Žebříček 🏆</h1>
            <div className="space-y-3">
                {users.sort((a,b) => (b.celkoveSkore || 0) - (a.celkoveSkore || 0)).map((u, i) => (
                    <div key={i} className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-sm flex items-center justify-between border border-gray-100 dark:border-gray-700">
                        <div className="flex items-center gap-4">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${i===0 ? 'bg-yellow-100 text-yellow-600 dark:bg-yellow-900 dark:text-yellow-300' : 'bg-gray-100 text-gray-500 dark:bg-gray-700 dark:text-gray-300'}`}>{i+1}</div>
                            <span className="font-medium text-gray-800 dark:text-gray-200">{u.displayName}</span>
                        </div>
                        <span className="font-bold text-indigo-600 dark:text-indigo-400">{u.celkoveSkore}</span>
                    </div>
                ))}
            </div>
        </div>
    );
};

const Flashcards = () => {
    const cards = db.getFlashcards();
    const [flipped, setFlipped] = useState<string | null>(null);
    
    return (
         <div className="p-6 pt-10 pb-24">
            <h1 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white">Kartičky</h1>
            {cards.length === 0 ? (
                <div className="text-center text-gray-500 dark:text-gray-400 mt-10">Zatím žádné kartičky. Vytvoř je po testu!</div>
            ) : (
                <div className="space-y-4">
                    {cards.map(card => (
                        <div key={card.id} onClick={() => setFlipped(flipped === card.id ? null : card.id)} 
                             className="aspect-video bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 p-6 flex items-center justify-center text-center cursor-pointer transition-all relative perspective-1000">
                             <div className="text-sm uppercase text-gray-400 dark:text-gray-500 absolute top-4 left-4">{card.category}</div>
                             <p className="font-medium text-lg text-gray-800 dark:text-gray-100">
                                 {flipped === card.id ? card.back : card.front}
                             </p>
                             <div className="absolute bottom-4 text-xs text-indigo-500 dark:text-indigo-400">Klikni pro otočení</div>
                        </div>
                    ))}
                </div>
            )}
         </div>
    );
};

const Profile = ({ user, isDark, toggleTheme }: { user: User; isDark: boolean; toggleTheme: () => void }) => (
    <div className="p-6 pt-10 pb-24">
        <div className="text-center mb-8">
            <div className="w-24 h-24 bg-gray-200 dark:bg-gray-700 rounded-full mx-auto mb-4 border-4 border-white dark:border-gray-800 shadow-md"></div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{user.displayName}</h1>
            <p className="text-gray-600 dark:text-gray-400">@{user.username}</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm mb-6 border border-gray-100 dark:border-gray-700">
             <div className="flex justify-between border-b border-gray-100 dark:border-gray-700 pb-4 mb-4">
                 <span className="text-gray-700 dark:text-gray-300">Celkové skóre</span>
                 <span className="font-bold text-gray-900 dark:text-white">{user.celkoveSkore}</span>
             </div>
             <div className="flex justify-between">
                 <span className="text-gray-700 dark:text-gray-300">Streak</span>
                 <span className="font-bold text-orange-500">{user.pocetDniStreak} 🔥</span>
             </div>
        </div>

        <div className="space-y-2">
             <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider ml-2">Nastavení</h3>
             <button 
                onClick={toggleTheme}
                className="w-full bg-white dark:bg-gray-800 p-4 rounded-2xl border border-gray-100 dark:border-gray-700 flex items-center justify-between active:scale-[0.98] transition-transform"
             >
                <div className="flex items-center gap-3">
                    <div className="p-2 bg-indigo-50 dark:bg-gray-700 rounded-full text-indigo-600 dark:text-indigo-300">
                        {isDark ? <Moon size={20} /> : <Sun size={20} />}
                    </div>
                    <span className="font-medium text-gray-800 dark:text-gray-200">Tmavý režim</span>
                </div>
                <div className={`w-12 h-6 rounded-full p-1 transition-colors duration-300 ${isDark ? 'bg-indigo-600' : 'bg-gray-200'}`}>
                    <div className={`bg-white w-4 h-4 rounded-full shadow-sm transform transition-transform duration-300 ${isDark ? 'translate-x-6' : 'translate-x-0'}`}></div>
                </div>
             </button>
        </div>
    </div>
);

const AITutor = () => {
    const [messages, setMessages] = useState<{role: 'user'|'model', text: string}[]>([
        {role: 'model', text: 'Ahoj! Jsem tvůj AI učitel. S čím potřebuješ pomoct?'}
    ]);
    const [input, setInput] = useState('');
    const [loading, setLoading] = useState(false);

    const send = async () => {
        if (!input.trim()) return;
        const newHistory = [...messages, {role: 'user' as const, text: input}];
        setMessages(newHistory);
        setInput('');
        setLoading(true);

        // Format history for Gemini SDK
        const apiHistory = newHistory.map(m => ({ role: m.role, parts: [{ text: m.text }] }));
        
        const response = await geminiService.chatWithTutor(input, apiHistory.slice(0, -1) as any);
        
        setMessages(prev => [...prev, {role: 'model', text: response}]);
        setLoading(false);
    };

    const saveToNotes = (text: string) => {
        db.saveAINote('Chat s AI', text);
        alert('Uloženo do poznámek!');
    };

    return (
        <div className="flex flex-col h-screen pb-20 bg-gray-50 dark:bg-gray-900">
             <div className="p-4 bg-white dark:bg-gray-800 shadow-sm sticky top-0 z-10 border-b border-gray-100 dark:border-gray-700">
                 <h1 className="font-bold text-lg text-gray-900 dark:text-white">AI Doučování</h1>
             </div>
             <div className="flex-1 overflow-y-auto p-4 space-y-4">
                 {messages.map((m, i) => (
                     <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                         <div className={`max-w-[85%] p-3 rounded-2xl text-sm leading-relaxed ${
                             m.role === 'user' 
                             ? 'bg-indigo-600 text-white' 
                             : 'bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-200'
                         }`}>
                             {m.text}
                             {m.role === 'model' && (
                                 <button onClick={() => saveToNotes(m.text)} className="mt-2 text-xs opacity-60 hover:opacity-100 flex items-center gap-1 text-gray-500 dark:text-gray-400 border-t border-gray-100 dark:border-gray-600 pt-2 w-full"><Save size={12}/> Uložit</button>
                             )}
                         </div>
                     </div>
                 ))}
                 {loading && <div className="text-center text-xs text-gray-400 dark:text-gray-500">AI píše...</div>}
             </div>
             <div className="p-4 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 flex gap-2">
                 <input 
                    value={input} onChange={e => setInput(e.target.value)}
                    placeholder="Zeptej se..." 
                    className="flex-1 bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white rounded-full px-4 py-3 outline-none focus:ring-2 ring-indigo-500 transition-colors"
                    onKeyDown={e => e.key === 'Enter' && send()}
                 />
                 <button onClick={send} className="bg-indigo-600 hover:bg-indigo-700 text-white p-3 rounded-full transition-colors shadow-lg shadow-indigo-500/30"><ArrowRight size={20}/></button>
             </div>
        </div>
    );
};

export default function App() {
  const [view, setView] = useState<ViewState>('home');
  const [user, setUser] = useState<User | null>(null);
  const [examConfig, setExamConfig] = useState<ExamConfig | undefined>(undefined);
  const [darkMode, setDarkMode] = useState<boolean>(() => {
      return localStorage.getItem('theme') === 'dark';
  });

  useEffect(() => {
    // Initialize user and check streak
    const u = db.checkStreak();
    setUser(u);
  }, [view]);

  useEffect(() => {
      if (darkMode) {
          document.documentElement.classList.add('dark');
          localStorage.setItem('theme', 'dark');
      } else {
          document.documentElement.classList.remove('dark');
          localStorage.setItem('theme', 'light');
      }
  }, [darkMode]);

  const handleStartExam = (config?: ExamConfig) => {
      setExamConfig(config);
      setView('exam_session');
  };

  const toggleTheme = () => setDarkMode(!darkMode);

  if (!user) return <div className="flex items-center justify-center h-screen bg-gray-50 dark:bg-gray-900"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div></div>;

  return (
    <div className={darkMode ? 'dark' : ''}>
        <div className="max-w-md mx-auto bg-gray-50 dark:bg-gray-900 min-h-screen shadow-2xl overflow-hidden relative transition-colors duration-300">
        
        {view === 'home' && <Home user={user} setView={setView} startQuickExam={handleStartExam} />}
        
        {view === 'exam_select' && <Exam onBack={() => setView('home')} />}
        
        {view === 'exam_session' && <Exam config={examConfig} onBack={() => setView('home')} />}
        
        {view === 'leaderboard' && <Leaderboard />}
        
        {view === 'flashcards' && <Flashcards />}
        
        {view === 'profile' && <Profile user={user} isDark={darkMode} toggleTheme={toggleTheme} />}

        {view === 'ai_tutor' && <AITutor />}

        {view !== 'exam_session' && view !== 'ai_tutor' && (
            <BottomNav currentView={view} setView={setView} />
        )}
        </div>
    </div>
  );
}