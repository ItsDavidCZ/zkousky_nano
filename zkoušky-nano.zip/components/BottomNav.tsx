import React from 'react';
import { Home, Award, FileText, Layers, User } from 'lucide-react';
import { ViewState } from '../types';

interface BottomNavProps {
  currentView: ViewState;
  setView: (view: ViewState) => void;
}

const BottomNav: React.FC<BottomNavProps> = ({ currentView, setView }) => {
  const navItems = [
    { id: 'home', label: 'Domů', icon: Home },
    { id: 'leaderboard', label: 'Žebříček', icon: Award },
    { id: 'exam_select', label: 'Zkouška', icon: FileText },
    { id: 'flashcards', label: 'Kartičky', icon: Layers },
    { id: 'profile', label: 'Profil', icon: User },
  ];

  return (
    <nav className="fixed bottom-0 w-full glass-panel z-50 pb-1 pt-2 px-4 border-t border-white/40 dark:border-white/10 rounded-t-2xl transition-all duration-300">
      <div className="flex justify-between items-center max-w-md mx-auto">
        {navItems.map((item) => {
          const isActive = currentView === item.id || (item.id === 'exam_select' && currentView === 'exam_session');
          return (
            <button
              key={item.id}
              onClick={() => setView(item.id as ViewState)}
              className={`flex flex-col items-center justify-center w-16 transition-all duration-300 ${
                isActive ? 'text-primary dark:text-indigo-400 -translate-y-2' : 'text-gray-500 dark:text-gray-400'
              }`}
            >
              <div className={`p-2 rounded-full ${isActive ? 'bg-white dark:bg-gray-800 shadow-md dark:shadow-black/30' : ''}`}>
                <item.icon size={isActive ? 24 : 22} strokeWidth={isActive ? 2.5 : 2} />
              </div>
              <span className={`text-[10px] mt-1 font-medium ${isActive ? 'opacity-100' : 'opacity-80'}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNav;