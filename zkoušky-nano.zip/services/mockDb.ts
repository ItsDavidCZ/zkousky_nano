import { User, Question, ErrorLog, Flashcard, AINote } from '../types';

// --- Mock Data Initialization ---
const MOCK_QUESTIONS: Question[] = [
  {
    id: 'q1',
    predmet: 'Čeština',
    tema: 'Pravopis',
    otazka: 'Která věta je napsána pravopisně správně?',
    odpovedA: 'Byli jsme s mylími přáteli.',
    odpovedB: 'Byli jsme s milými přáteli.',
    odpovedC: 'Byly jsme s milými přáteli.',
    spravnaOdpoved: 'B',
    vysvetleniChyby: 'Přídavné jméno "milý" je tvrdé/měkké podle vzoru "mladý", ale kořen slova "mil-" píšeme s měkkým i (milovat). Podmět "my" (nevyjádřený) vyžaduje shodu přísudku (byli).',
    isCritical: true
  },
  {
    id: 'q2',
    predmet: 'Matematika',
    tema: 'Rovnice',
    otazka: 'Řešte rovnici: 2x + 5 = 15',
    odpovedA: 'x = 5',
    odpovedB: 'x = 10',
    odpovedC: 'x = 2.5',
    spravnaOdpoved: 'A',
    vysvetleniChyby: '2x = 15 - 5 => 2x = 10 => x = 5.',
    isCritical: false
  },
  {
    id: 'q3',
    predmet: 'Čeština',
    tema: 'Literatura',
    otazka: 'Kdo napsal R.U.R.?',
    odpovedA: 'Karel Čapek',
    odpovedB: 'Franz Kafka',
    odpovedC: 'Jaroslav Hašek',
    spravnaOdpoved: 'A',
    vysvetleniChyby: 'R.U.R. (Rossumovi Univerzální Roboti) je drama Karla Čapka z roku 1920.',
    isCritical: false
  },
  {
    id: 'q4',
    predmet: 'Matematika',
    tema: 'Geometrie',
    otazka: 'Jaký je obsah čtverce o straně 6 cm?',
    odpovedA: '24 cm²',
    odpovedB: '36 cm²',
    odpovedC: '12 cm²',
    spravnaOdpoved: 'B',
    vysvetleniChyby: 'Obsah čtverce S = a * a. Tedy 6 * 6 = 36.',
    isCritical: true
  }
];

const CURRENT_USER_ID = 'user_demo_1';

// --- Service Layer ---

export const db = {
  // User Logic
  getCurrentUser: (): User => {
    const stored = localStorage.getItem('currentUser');
    if (stored) return JSON.parse(stored);
    
    const newUser: User = {
      id: CURRENT_USER_ID,
      email: 'student@skola.cz',
      displayName: 'Nový Student',
      username: 'student123',
      celkoveSkore: 0,
      pocetDniStreak: 1,
      posledniPrihlaseni: new Date().toISOString()
    };
    localStorage.setItem('currentUser', JSON.stringify(newUser));
    return newUser;
  },

  updateUser: (updates: Partial<User>) => {
    const user = db.getCurrentUser();
    const updated = { ...user, ...updates };
    localStorage.setItem('currentUser', JSON.stringify(updated));
    return updated;
  },

  checkStreak: (): User => {
    const user = db.getCurrentUser();
    const lastLogin = new Date(user.posledniPrihlaseni);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - lastLogin.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    let newStreak = user.pocetDniStreak;

    // Simple logic: if it's the same day, do nothing. If it's next day, +1. If gap > 1 day, reset.
    // Accurate day check requires verifying calendar date strings.
    const isSameDay = lastLogin.toDateString() === now.toDateString();
    const isNextDay =  (now.getDate() - lastLogin.getDate() === 1) || (diffDays === 1 && !isSameDay);

    if (!isSameDay) {
      if (isNextDay) {
        newStreak += 1;
      } else {
        newStreak = 1;
      }
      const updated = db.updateUser({
        pocetDniStreak: newStreak,
        posledniPrihlaseni: now.toISOString()
      });
      return updated;
    }
    
    // Always update timestamp even if same day to keep it fresh
    db.updateUser({ posledniPrihlaseni: now.toISOString() });
    return user;
  },

  // Questions
  getQuestions: (): Question[] => {
    // Simulate "DB"
    return MOCK_QUESTIONS;
  },

  // Error Log
  logError: (questionId: string) => {
    const logs: ErrorLog[] = JSON.parse(localStorage.getItem('errorLog') || '[]');
    const newLog: ErrorLog = {
      id: Date.now().toString(),
      userId: CURRENT_USER_ID,
      questionId,
      timestamp: new Date().toISOString(),
      isCorrected: false
    };
    logs.push(newLog);
    localStorage.setItem('errorLog', JSON.stringify(logs));
  },

  getErrors: (): ErrorLog[] => {
    return JSON.parse(localStorage.getItem('errorLog') || '[]');
  },

  markErrorCorrected: (questionId: string) => {
    const logs: ErrorLog[] = JSON.parse(localStorage.getItem('errorLog') || '[]');
    const updatedLogs = logs.map(l => 
      (l.questionId === questionId && l.userId === CURRENT_USER_ID) 
        ? { ...l, isCorrected: true } 
        : l
    );
    localStorage.setItem('errorLog', JSON.stringify(updatedLogs));
  },

  // Flashcards
  addFlashcards: (cards: Omit<Flashcard, 'id' | 'userId'>[]) => {
    const existing: Flashcard[] = JSON.parse(localStorage.getItem('flashcards') || '[]');
    const newCards = cards.map(c => ({
      ...c,
      id: Math.random().toString(36).substr(2, 9),
      userId: CURRENT_USER_ID
    }));
    localStorage.setItem('flashcards', JSON.stringify([...existing, ...newCards]));
  },

  getFlashcards: (): Flashcard[] => {
    const all: Flashcard[] = JSON.parse(localStorage.getItem('flashcards') || '[]');
    return all.filter(f => f.userId === CURRENT_USER_ID);
  },

  // AI Notes
  saveAINote: (title: string, content: string) => {
    const notes: AINote[] = JSON.parse(localStorage.getItem('aiNotes') || '[]');
    const newNote: AINote = {
      id: Math.random().toString(36).substr(2, 9),
      userId: CURRENT_USER_ID,
      title,
      content,
      createdAt: new Date().toISOString()
    };
    localStorage.setItem('aiNotes', JSON.stringify([...notes, newNote]));
  }
};
