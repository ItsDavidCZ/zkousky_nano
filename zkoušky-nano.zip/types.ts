export interface User {
  id: string;
  email: string;
  displayName: string;
  username: string;
  celkoveSkore: number;
  pocetDniStreak: number;
  posledniPrihlaseni: string; // ISO Date string
}

export interface Question {
  id: string;
  predmet: 'Matematika' | 'Čeština';
  tema: string;
  otazka: string;
  odpovedA: string;
  odpovedB: string;
  odpovedC: string;
  spravnaOdpoved: 'A' | 'B' | 'C';
  vysvetleniChyby: string;
  isCritical: boolean;
  examSection?: string;
}

export interface Progress {
  userId: string;
  tema: string;
  spravneOdpovediPocet: number;
  celkemOdpovediPocet: number;
}

export interface ErrorLog {
  id: string;
  userId: string;
  questionId: string;
  timestamp: string;
  isCorrected: boolean;
}

export interface Flashcard {
  id: string;
  userId: string;
  category: string;
  front: string;
  back: string;
}

export interface AINote {
  id: string;
  userId: string;
  title: string;
  content: string;
  createdAt: string;
}

// App Navigation Types
export type ViewState = 'home' | 'leaderboard' | 'exam_select' | 'exam_session' | 'flashcards' | 'profile' | 'ai_tutor';

export interface ExamConfig {
  mode: 'simulation' | 'panic' | 'review';
  subject?: 'Matematika' | 'Čeština';
  duration?: number; // in seconds
}
